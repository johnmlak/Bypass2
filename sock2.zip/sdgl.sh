alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
E 
E 
E 
E "\033[1;37m                _______________________  \033[0m"
E "\033[1;37m                 \033[41m  @ID device 😍     \033[0m"
E "\033[1;37m                ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  \033[0m"
echo ""
echo ""
echo "[5;33m PLEASE WAIT"
echo "[5;33m............................"
S 2
clear
X=$(grep -n com.tencent.ig /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
X=$(grep -n com.pubg.krmobile /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
Xx=$(head -3 /dev/urandom | tr -cd 'a-z0-9' | cut -c -16)
sed -i "s/$X/$Xx/g" /data/system/users/0/settings_ssaid.xml
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo"start make file "
r=$(( $RANDOM % 10 )); 
rr=$(( $RANDOM % 10 )); 
g=$h;
echo "random code "
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name="random"></string>
    <string name="install">8a6327b0-"$r"1fd-"$rr$rr$r$r"-b10b-1d0d3ee67e9d</string>
    <string name="uuid">df20f8e421669c96"tk$r$rr$rr$r"523181d5f0</string>
    <string name="fd4fe0aa9d553f705e"kj$rr$r$r"1cd31bdf1">toZINy6Z/c9QPf48666c0Uz0QVQtWteBsgo/0UiuKOGhB/x91xZ86LrK9PWYZkx/</string>
</map>
" > settings_ssaid.xml
echo "wait for move file"
cd /data/system/users/0
rm -rf /data/system/users/0/settings_ssaid.xml
echo "restart device "
mv "${DIR}"/settings_ssaid.xml /data/system/users/0/settings_ssaid.xml
echo "done"
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X;
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X
su -c reboot



